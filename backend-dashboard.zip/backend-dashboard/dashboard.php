<?php
require_once 'config/database.php';
require_once 'utils/functions.php';
require_once 'config/auth.php';

// Check authentication
checkAuth();

// Get counts for each section
try {
    $counts = [];
    
    // Emergency Numbers
    $stmt = $pdo->query("SELECT COUNT(*) FROM emergency_numbers");
    $counts['emergency'] = $stmt->fetchColumn();
    
    // Hospitals
    $stmt = $pdo->query("SELECT COUNT(*) FROM hospitals");
    $counts['hospitals'] = $stmt->fetchColumn();
    
    // Doctors
    $stmt = $pdo->query("SELECT COUNT(*) FROM doctors");
    $counts['doctors'] = $stmt->fetchColumn();
    
    // Schools
    $stmt = $pdo->query("SELECT COUNT(*) FROM schools");
    $counts['schools'] = $stmt->fetchColumn();
    
    // Banks
    $stmt = $pdo->query("SELECT COUNT(*) FROM banks");
    $counts['banks'] = $stmt->fetchColumn();
    
    // Ambulances
    $stmt = $pdo->query("SELECT COUNT(*) FROM ambulances");
    $counts['ambulances'] = $stmt->fetchColumn();
    
    // Trucks
    $stmt = $pdo->query("SELECT COUNT(*) FROM trucks");
    $counts['trucks'] = $stmt->fetchColumn();
    
    // Blood Donors
    $stmt = $pdo->query("SELECT COUNT(*) FROM blood_donors");
    $counts['blood_donors'] = $stmt->fetchColumn();
    
    // Mechanics
    $stmt = $pdo->query("SELECT COUNT(*) FROM mechanics");
    $counts['mechanics'] = $stmt->fetchColumn();
    
} catch (PDOException $e) {
    $error = 'Error fetching counts: ' . $e->getMessage();
}

$page_title = 'Dashboard Overview';

// Start output buffering
ob_start();
?>

<div class="container mx-auto px-4 py-8">
    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- Emergency Numbers Card -->
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-blue-100 text-sm font-medium">Emergency Numbers</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['emergency']; ?></h3>
                    </div>
                    <div class="bg-blue-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-phone text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="emergency_numbers.php" class="text-blue-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Hospitals Card -->
        <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-green-100 text-sm font-medium">Hospitals</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['hospitals']; ?></h3>
                    </div>
                    <div class="bg-green-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-hospital text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="hospitals.php" class="text-green-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Doctors Card -->
        <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-purple-100 text-sm font-medium">Doctors</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['doctors']; ?></h3>
                    </div>
                    <div class="bg-purple-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-user-md text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="doctors.php" class="text-purple-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Schools Card -->
        <div class="bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-yellow-100 text-sm font-medium">Schools</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['schools']; ?></h3>
                    </div>
                    <div class="bg-yellow-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-school text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="schools.php" class="text-yellow-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Banks Card -->
        <div class="bg-gradient-to-br from-red-500 to-red-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-red-100 text-sm font-medium">Banks</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['banks']; ?></h3>
                    </div>
                    <div class="bg-red-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-university text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="banks.php" class="text-red-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Ambulances Card -->
        <div class="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-pink-100 text-sm font-medium">Ambulances</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['ambulances']; ?></h3>
                    </div>
                    <div class="bg-pink-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-ambulance text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="ambulances.php" class="text-pink-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Trucks Card -->
        <div class="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-indigo-100 text-sm font-medium">Trucks</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['trucks']; ?></h3>
                    </div>
                    <div class="bg-indigo-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-truck text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="trucks.php" class="text-indigo-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Blood Donors Card -->
        <div class="bg-gradient-to-br from-rose-500 to-rose-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-rose-100 text-sm font-medium">Blood Donors</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['blood_donors']; ?></h3>
                    </div>
                    <div class="bg-rose-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-heartbeat text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="blood_donors.php" class="text-rose-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>

        <!-- Mechanics Card -->
        <div class="bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-xl shadow-lg overflow-hidden transform hover:scale-105 transition duration-300">
            <div class="p-6">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-cyan-100 text-sm font-medium">Mechanics</p>
                        <h3 class="text-3xl font-bold text-white mt-2"><?php echo $counts['mechanics']; ?></h3>
                    </div>
                    <div class="bg-cyan-400 bg-opacity-20 p-3 rounded-full">
                        <i class="fas fa-tools text-white text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="mechanics.php" class="text-cyan-100 hover:text-white text-sm font-medium flex items-center">
                        View Details
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Get the buffered content
$content = ob_get_clean();

// Include the main layout
require_once 'layouts/main.php';
?> 