<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM emergency_numbers WHERE id = ?");
        $stmt->execute([$id]);
        $message = 'Emergency number deleted successfully';
        // Redirect to prevent refresh from resubmitting delete
        header("Location: emergency_numbers.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting emergency number: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM emergency_numbers WHERE id = ?");
        $stmt->execute([$id]);
        $edit_number = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching emergency number: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $description = sanitizeInput($_POST['description']);

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!preg_match('/^[0-9]+$/', $phone_number)) {
        $error = 'Phone number must contain only numbers';
    } elseif (strlen($phone_number) < 1 || strlen($phone_number) > 20) {
        $error = 'Phone number must be between 1 to 20 characters';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM emergency_numbers WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                if (isset($_POST['id'])) {
                    // Update existing record
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE emergency_numbers SET name = ?, phone_number = ?, description = ? WHERE id = ?");
                    $stmt->execute([$name, $phone_number, $description, $id]);
                    $message = 'Emergency number updated successfully';
                } else {
                    // Insert new record
                    $stmt = $pdo->prepare("INSERT INTO emergency_numbers (name, phone_number, description) VALUES (?, ?, ?)");
                    $stmt->execute([$name, $phone_number, $description]);
                    $message = 'Emergency number added successfully';
                }
                // Redirect to prevent form resubmission
                header("Location: emergency_numbers.php?message=" . urlencode($message));
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Error saving emergency number: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all emergency numbers
$stmt = $pdo->query("SELECT * FROM emergency_numbers ORDER BY created_at DESC");
$emergency_numbers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Emergency Numbers</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_number) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_number) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" class="space-y-4" onsubmit="return true;">
            ' . (isset($edit_number) ? '<input type="hidden" name="id" value="' . $edit_number['id'] . '">' : '') . '
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_number) ? htmlspecialchars($edit_number['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       pattern="[0-9]*" 
                       inputmode="numeric"
                       onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                       value="' . (isset($edit_number) ? htmlspecialchars($edit_number['phone_number']) : '') . '">
                <p class="text-gray-500 text-xs mt-1">Only numbers are allowed</p>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_number) ? htmlspecialchars($edit_number['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_number) ? 'Update Emergency Number' : 'Add Emergency Number') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">';

foreach ($emergency_numbers as $number) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($number['name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($number['phone_number']) . '</td>
                    <td class="px-6 py-4">' . htmlspecialchars($number['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $number['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $number['id'] . '" onclick="return confirm(\'Are you sure you want to delete this emergency number?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 