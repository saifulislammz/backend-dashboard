<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM ambulances WHERE id = ?");
        $stmt->execute([$id]);
        $message = 'Ambulance deleted successfully';
        header("Location: ambulances.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting ambulance: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM ambulances WHERE id = ?");
        $stmt->execute([$id]);
        $edit_ambulance = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching ambulance: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $driver_name = sanitizeInput($_POST['driver_name']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $description = sanitizeInput($_POST['description']);

    if (empty($driver_name)) {
        $error = 'Driver name is required';
    } elseif (!validateBangladeshiPhoneNumber($phone_number)) {
        $error = 'Invalid Bangladeshi phone number';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM ambulances WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                if (isset($_POST['id'])) {
                    // Update existing record
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE ambulances SET driver_name = ?, phone_number = ?, description = ? WHERE id = ?");
                    $stmt->execute([$driver_name, $phone_number, $description, $id]);
                    $message = 'Ambulance updated successfully';
                } else {
                    // Insert new record
                    $stmt = $pdo->prepare("INSERT INTO ambulances (driver_name, phone_number, description) VALUES (?, ?, ?)");
                    $stmt->execute([$driver_name, $phone_number, $description]);
                    $message = 'Ambulance added successfully';
                }
                header("Location: ambulances.php?message=" . urlencode($message));
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Error saving ambulance: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all ambulances
$stmt = $pdo->query("SELECT * FROM ambulances ORDER BY created_at DESC");
$ambulances = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Ambulances</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_ambulance) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_ambulance) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" class="space-y-4">
            ' . (isset($edit_ambulance) ? '<input type="hidden" name="id" value="' . $edit_ambulance['id'] . '">' : '') . '
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="driver_name">
                    Driver Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="driver_name" name="driver_name" type="text" required
                       value="' . (isset($edit_ambulance) ? htmlspecialchars($edit_ambulance['driver_name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       value="' . (isset($edit_ambulance) ? htmlspecialchars($edit_ambulance['phone_number']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_ambulance) ? htmlspecialchars($edit_ambulance['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_ambulance) ? 'Update Ambulance' : 'Add Ambulance') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($ambulances as $ambulance) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($ambulance['driver_name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($ambulance['phone_number']) . '</td>
                    <td class="px-6 py-4">' . htmlspecialchars($ambulance['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $ambulance['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $ambulance['id'] . '" onclick="return confirm(\'Are you sure you want to delete this ambulance?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 