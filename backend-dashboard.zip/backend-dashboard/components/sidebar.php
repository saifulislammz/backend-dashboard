<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="fixed top-0 left-0 h-full w-64 bg-gray-800 text-white transition-all duration-300 ease-in-out">
    <div class="p-4">
        <h2 class="text-2xl font-bold mb-6">Dashboard</h2>
        <nav>
            <ul class="space-y-2">
                <li>
                    <a href="dashboard.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'dashboard.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-home w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="emergency_numbers.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'emergency_numbers.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-phone w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Emergency Numbers</span>
                    </a>
                </li>
                <li>
                    <a href="hospitals.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'hospitals.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-hospital w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Hospitals</span>
                    </a>
                </li>
                <li>
                    <a href="doctors.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'doctors.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-user-md w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Doctors</span>
                    </a>
                </li>
                <li>
                    <a href="schools.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'schools.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-school w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Schools</span>
                    </a>
                </li>
                <li>
                    <a href="banks.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'banks.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-university w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Banks</span>
                    </a>
                </li>
                <li>
                    <a href="ambulances.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'ambulances.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-ambulance w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Ambulances</span>
                    </a>
                </li>
                <li>
                    <a href="trucks.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'trucks.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-truck w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Trucks</span>
                    </a>
                </li>
                <li>
                    <a href="blood_donors.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'blood_donors.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-tint w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Blood Donors</span>
                    </a>
                </li>
                <li>
                    <a href="mechanics.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'mechanics.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-wrench w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Mechanics</span>
                    </a>
                </li>
                <li>
                    <a href="settings.php" class="flex items-center p-2 rounded hover:bg-gray-700 <?php echo $current_page === 'settings.php' ? 'bg-gray-700' : ''; ?>">
                        <i class="fas fa-cog w-5 h-5 text-gray-500 transition duration-75 group-hover:text-gray-900"></i>
                        <span class="ml-3">Settings</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div> 