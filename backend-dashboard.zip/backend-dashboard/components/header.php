<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<header class="fixed top-0 right-0 z-30 w-full h-16 bg-white border-b border-gray-200">
    <div class="flex items-center justify-between h-full px-4">
        <!-- Logo -->
        <div class="flex items-center">
            <div class="text-2xl font-bold bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                <span class="tracking-tight">Admin</span>
                <span class="font-light">Panel</span>
            </div>
        </div>

        <!-- Search Box -->
        <div class="flex-1 max-w-2xl mx-4">
            <div class="relative">
                <form action="search.php" method="GET" class="flex items-center">
                    <div class="relative flex-1">
                        <input type="text" 
                               name="q" 
                               id="search-input"
                               class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                               placeholder="Search anything..."
                               autocomplete="off">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-search text-gray-400"></i>
                        </div>
                    </div>
                    <div class="ml-2">
                        <select name="category" 
                                class="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                            <option value="all">All Categories</option>
                            <option value="emergency">Emergency Numbers</option>
                            <option value="hospitals">Hospitals</option>
                            <option value="doctors">Doctors</option>
                            <option value="schools">Schools</option>
                            <option value="banks">Banks</option>
                            <option value="ambulances">Ambulances</option>
                            <option value="trucks">Trucks</option>
                            <option value="blood_donors">Blood Donors</option>
                            <option value="mechanics">Mechanics</option>
                        </select>
                    </div>
                    <button type="submit" 
                            class="ml-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                        Search
                    </button>
                </form>
            </div>
        </div>

        <!-- Right side content -->
        <div class="flex items-center space-x-4">
            <!-- User dropdown -->
            <div class="relative">
                <button id="user-menu-button" class="flex items-center space-x-2 focus:outline-none">
                    <span class="text-gray-700"><?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <i class="fas fa-chevron-down text-gray-500"></i>
                </button>
                
                <!-- Dropdown menu -->
                <div id="user-dropdown" class="hidden absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1">
                    <a href="settings.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        <i class="fas fa-cog mr-2"></i> Settings
                    </a>
                    <a href="logout.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
// User dropdown toggle
document.getElementById('user-menu-button').addEventListener('click', function() {
    document.getElementById('user-dropdown').classList.toggle('hidden');
});

// Close dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('user-dropdown');
    const button = document.getElementById('user-menu-button');
    
    if (!button.contains(event.target) && !dropdown.contains(event.target)) {
        dropdown.classList.add('hidden');
    }
});

// Search input focus handler
document.getElementById('search-input').addEventListener('focus', function() {
    this.parentElement.classList.add('ring-2', 'ring-blue-500');
});

document.getElementById('search-input').addEventListener('blur', function() {
    this.parentElement.classList.remove('ring-2', 'ring-blue-500');
});
</script> 