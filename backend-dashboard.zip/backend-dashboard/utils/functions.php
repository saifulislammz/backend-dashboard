<?php
function validateGoogleMapUrl($url) {
    // Google Maps URL validation for https://maps.app.goo.gl/ format
    $pattern = '/^https:\/\/maps\.app\.goo\.gl\/.*$/';
    return preg_match($pattern, $url);
}

function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function handleFileUpload($file, $target_dir = 'uploads/') {
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $target_file = $target_dir . basename($file["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    // Check if image file is a actual image or fake image
    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return false;
    }

    // Check file size (5MB max)
    if ($file["size"] > 5000000) {
        return false;
    }

    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
        return false;
    }

    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return $target_file;
    }
    return false;
}

function showAlert($message, $type = 'success') {
    $classes = [
        'success' => 'bg-green-100 border-green-400 text-green-700',
        'error' => 'bg-red-100 border-red-400 text-red-700',
        'warning' => 'bg-yellow-100 border-yellow-400 text-yellow-700'
    ];
    
    $class = $classes[$type] ?? $classes['success'];
    
    return "
        <div class='$class border px-4 py-3 rounded relative mb-4' role='alert'>
            <span class='block sm:inline'>$message</span>
        </div>
    ";
}

function validateBangladeshiPhoneNumber($phone) {
    // Remove any non-digit characters
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // Check if the number starts with 01 and has 11 digits
    if (preg_match('/^01[3-9]\d{8}$/', $phone)) {
        return true;
    }
    
    // Check if the number starts with 8801 and has 13 digits
    if (preg_match('/^8801[3-9]\d{8}$/', $phone)) {
        return true;
    }
    
    return false;
}
?> 