<?php
require_once 'config/database.php';
require_once 'utils/functions.php';
require_once 'config/auth.php';

// Check if user is already logged in
checkLoginPage();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password';
    } else {
        try {
            // Check if IP is blocked
            $stmt = $pdo->prepare("
                SELECT block_time, unblock_time 
                FROM blocked_ips 
                WHERE ip_address = ? 
                AND (unblock_time IS NULL OR unblock_time > NOW())
            ");
            $stmt->execute([$ip_address]);
            $blocked = $stmt->fetch();

            if ($blocked) {
                if ($blocked['unblock_time']) {
                    $unblock_time = new DateTime($blocked['unblock_time']);
                    $now = new DateTime();
                    $diff = $now->diff($unblock_time);
                    $minutes = $diff->i;
                    $seconds = $diff->s;
                    $error = "Your IP has been blocked. Please try again in {$minutes} minutes and {$seconds} seconds.";
                } else {
                    $error = "Your IP has been permanently blocked due to suspicious activity.";
                }
            } else {
                // Check for recent failed attempts
                $stmt = $pdo->prepare("
                    SELECT COUNT(*) 
                    FROM login_attempts 
                    WHERE ip_address = ? 
                    AND username = ? 
                    AND is_successful = 0 
                    AND attempt_time > DATE_SUB(NOW(), INTERVAL 15 MINUTE)
                ");
                $stmt->execute([$ip_address, $username]);
                $failed_attempts = $stmt->fetchColumn();

                if ($failed_attempts >= 2) {
                    // Block the IP for 15 minutes
                    $unblock_time = date('Y-m-d H:i:s', strtotime('+15 minutes'));
                    $stmt = $pdo->prepare("
                        INSERT INTO blocked_ips (ip_address, block_reason, unblock_time) 
                        VALUES (?, 'Too many failed login attempts', ?)
                        ON DUPLICATE KEY UPDATE 
                        block_reason = VALUES(block_reason),
                        unblock_time = VALUES(unblock_time)
                    ");
                    $stmt->execute([$ip_address, $unblock_time]);
                    
                    $error = 'Too many failed attempts. Your IP has been blocked for 15 minutes.';
                } else {
                    // First check if the user exists
                    $stmt = $pdo->prepare("SELECT id, username, password FROM admin_users WHERE username = ?");
                    $stmt->execute([$username]);
                    $user = $stmt->fetch();

                    if ($user) {
                        // Debug logging
                        error_log("User found: " . print_r($user, true));
                        error_log("Input password MD5: " . md5($password));
                        error_log("Stored password: " . $user['password']);
                        
                        // Verify password
                        $input_password_hash = md5($password);
                        if ($input_password_hash === $user['password']) {
                            // Record successful login attempt
                            $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username, is_successful) VALUES (?, ?, 1)");
                            $stmt->execute([$ip_address, $username]);

                            // Get current device count
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM login_devices WHERE admin_id = ?");
                            $stmt->execute([$user['id']]);
                            $device_count = $stmt->fetchColumn();

                            if ($device_count >= 2) {
                                // Get the oldest device
                                $stmt = $pdo->prepare("SELECT id, device_info FROM login_devices WHERE admin_id = ? ORDER BY last_login ASC LIMIT 1");
                                $stmt->execute([$user['id']]);
                                $oldest_device = $stmt->fetch();

                                // Remove the oldest device
                                $stmt = $pdo->prepare("DELETE FROM login_devices WHERE id = ?");
                                $stmt->execute([$oldest_device['id']]);

                                // Add message about automatic logout
                                $error = 'Maximum number of devices reached. The oldest device has been automatically logged out.';
                            }

                            // Get device info
                            $device_info = $_SERVER['HTTP_USER_AGENT'] . ' - ' . $ip_address;
                            
                            // Insert or update device info
                            $stmt = $pdo->prepare("INSERT INTO login_devices (admin_id, device_info) VALUES (?, ?) ON DUPLICATE KEY UPDATE last_login = CURRENT_TIMESTAMP");
                            $stmt->execute([$user['id'], $device_info]);
                            
                            // Regenerate session ID to prevent session fixation
                            session_regenerate_id(true);
                            
                            $_SESSION['admin_id'] = $user['id'];
                            $_SESSION['admin_username'] = $user['username'];
                            
                            // Set session cookie parameters
                            $params = session_get_cookie_params();
                            setcookie(session_name(), session_id(), time() + 3600, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
                            
                            // Redirect to the stored URL or dashboard
                            $redirect = isset($_SESSION['redirect_after_login']) ? $_SESSION['redirect_after_login'] : 'dashboard.php';
                            unset($_SESSION['redirect_after_login']);
                            header('Location: ' . $redirect);
                            exit();
                        } else {
                            // Record failed login attempt
                            $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username, is_successful) VALUES (?, ?, 0)");
                            $stmt->execute([$ip_address, $username]);

                            $error = 'Invalid password. Please check your password and try again.';
                            error_log("Password verification failed for user: " . $username);
                            error_log("Input password MD5: " . md5($password));
                            error_log("Stored password: " . $user['password']);
                        }
                    } else {
                        // Record failed login attempt for non-existent user
                        $stmt = $pdo->prepare("INSERT INTO login_attempts (ip_address, username, is_successful) VALUES (?, ?, 0)");
                        $stmt->execute([$ip_address, $username]);

                        $error = 'User not found';
                        error_log("User not found: " . $username);
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Error during login: ' . $e->getMessage();
            error_log("Database error: " . $e->getMessage());
        }
    }
}

// Clean up old login attempts (older than 24 hours)
try {
    $stmt = $pdo->prepare("DELETE FROM login_attempts WHERE attempt_time < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    $stmt->execute();
} catch (PDOException $e) {
    error_log("Error cleaning up login attempts: " . $e->getMessage());
}

// Clean up expired IP blocks
try {
    $stmt = $pdo->prepare("DELETE FROM blocked_ips WHERE unblock_time IS NOT NULL AND unblock_time < NOW()");
    $stmt->execute();
} catch (PDOException $e) {
    error_log("Error cleaning up expired IP blocks: " . $e->getMessage());
}

// Debug output
error_log("Login attempt - Username: " . (isset($username) ? $username : 'not set') . ", Error: " . $error);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Backend Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex items-center justify-center">
        <div class="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow-md">
            <div>
                <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                    Admin Login
                </h2>
            </div>
            
            <?php if ($error): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <form class="mt-8 space-y-6" method="POST">
                <div class="rounded-md shadow-sm -space-y-px">
                    <div>
                        <label for="username" class="sr-only">Username</label>
                        <input id="username" name="username" type="text" required 
                               class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                               placeholder="Username"
                               value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
                    </div>
                    <div>
                        <label for="password" class="sr-only">Password</label>
                        <input id="password" name="password" type="password" required 
                               class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-blue-500 focus:border-blue-500 focus:z-10 sm:text-sm" 
                               placeholder="Password">
                    </div>
                </div>

                <div>
                    <button type="submit" 
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Sign in
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html> 