<?php
require_once 'config/auth.php';
checkAuth();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backend Dashboard</title>
    <!-- Load scripts only once -->
    <?php if (!isset($GLOBALS['scripts_loaded'])): ?>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        colors: {
                            primary: '#1a56db',
                        }
                    }
                }
            }
        </script>
        <?php $GLOBALS['scripts_loaded'] = true; ?>
    <?php endif; ?>
</head>
<body class="bg-gray-100">
    <?php if (isset($_SESSION['admin_id']) && isset($_SESSION['admin_username'])): ?>
        <?php include __DIR__ . '/../components/sidebar.php'; ?>
        <?php include __DIR__ . '/../components/header.php'; ?>
        
        <main class="ml-64 p-6 mt-16">
            <div class="max-w-7xl mx-auto">
                <?php echo $content; ?>
            </div>
        </main>

        <script>
            // Sidebar toggle for mobile
            if (document.getElementById('sidebar-toggle')) {
                document.getElementById('sidebar-toggle').addEventListener('click', function() {
                    const sidebar = document.querySelector('.fixed');
                    if (sidebar) {
                        sidebar.classList.toggle('-translate-x-full');
                    }
                });
            }
        </script>
    <?php else: ?>
        <?php header('Location: login.php'); exit(); ?>
    <?php endif; ?>
</body>
</html> 