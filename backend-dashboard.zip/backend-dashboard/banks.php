<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $type = sanitizeInput($_POST['type']);
    $google_map_location = sanitizeInput($_POST['google_map_location']);
    $description = sanitizeInput($_POST['description']);

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!validateGoogleMapUrl($google_map_location)) {
        $error = 'Invalid Google Maps URL';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO banks (name, type, google_map_location, description) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $type, $google_map_location, $description]);
            $message = 'Bank added successfully';
        } catch (PDOException $e) {
            $error = 'Error adding bank: ' . $e->getMessage();
        }
    }
}

// Fetch all banks
$stmt = $pdo->query("SELECT * FROM banks ORDER BY created_at DESC");
$banks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Banks</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Add New
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="hidden bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="type">
                    Type *
                </label>
                <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                        id="type" name="type" required>
                    <option value="">Select Type</option>
                    <option value="Government">Government</option>
                    <option value="Private">Private</option>
                </select>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="google_map_location">
                    Google Map Location *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="google_map_location" name="google_map_location" type="url" required>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3"></textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    Add Bank
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Map Location</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($banks as $bank) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($bank['name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($bank['type']) . '</td>
                    <td class="px-6 py-4">
                        <a href="' . htmlspecialchars($bank['google_map_location']) . '" target="_blank" class="text-blue-600 hover:text-blue-900">
                            View Location
                        </a>
                    </td>
                    <td class="px-6 py-4">' . htmlspecialchars($bank['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="#" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="#" class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 