<?php
session_start();

function checkAuth() {
    // Check if user is logged in
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
        // Store the current page URL to redirect back after login
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: login.php');
        exit();
    }
    
    // Validate session
    if (!isValidSession()) {
        logout();
    }
}

function isValidSession() {
    if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
        return false;
    }
    
    // Add additional session validation if needed
    return true;
}

function logout() {
    // Clear all session variables
    $_SESSION = array();
    
    // Destroy the session cookie
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time() - 3600, '/');
    }
    
    // Destroy the session
    session_destroy();
    
    // Redirect to login page
    header('Location: login.php');
    exit();
}

// Check if user is trying to access login page while already logged in
function checkLoginPage() {
    if (isset($_SESSION['admin_id']) && isset($_SESSION['admin_username'])) {
        header('Location: dashboard.php');
        exit();
    }
}
?> 