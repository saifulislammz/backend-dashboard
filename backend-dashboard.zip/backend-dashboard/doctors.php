<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        // First get the picture filename to delete it from uploads
        $stmt = $pdo->prepare("SELECT picture FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delete the record
        $stmt = $pdo->prepare("DELETE FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete the picture file if it's not the default
        if ($doctor && $doctor['picture'] !== 'default-doctor.png') {
            $picture_path = 'uploads/' . $doctor['picture'];
            if (file_exists($picture_path)) {
                unlink($picture_path);
            }
        }
        
        $message = 'Doctor deleted successfully';
        header("Location: doctors.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting doctor: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM doctors WHERE id = ?");
        $stmt->execute([$id]);
        $edit_doctor = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching doctor: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $details = sanitizeInput($_POST['details']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $picture = isset($edit_doctor) ? $edit_doctor['picture'] : 'default-doctor.png';

    if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
        $upload_result = handleFileUpload($_FILES['picture']);
        if ($upload_result) {
            // Delete old picture if it's not the default
            if (isset($edit_doctor) && $edit_doctor['picture'] !== 'default-doctor.png') {
                $old_picture_path = 'uploads/' . $edit_doctor['picture'];
                if (file_exists($old_picture_path)) {
                    unlink($old_picture_path);
                }
            }
            $picture = basename($upload_result);
        } else {
            $error = 'Error uploading picture. Please try again.';
        }
    }

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (empty($details)) {
        $error = 'Doctor details are required';
    } elseif (!validateBangladeshiPhoneNumber($phone_number)) {
        $error = 'Invalid Bangladeshi phone number';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM doctors WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                if (isset($_POST['id'])) {
                    // Update existing record
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE doctors SET picture = ?, name = ?, details = ?, phone_number = ? WHERE id = ?");
                    $stmt->execute([$picture, $name, $details, $phone_number, $id]);
                    $message = 'Doctor updated successfully';
                } else {
                    // Insert new record
                    $stmt = $pdo->prepare("INSERT INTO doctors (picture, name, details, phone_number) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$picture, $name, $details, $phone_number]);
                    $message = 'Doctor added successfully';
                }
                header("Location: doctors.php?message=" . urlencode($message));
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Error saving doctor: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all doctors
$stmt = $pdo->query("SELECT * FROM doctors ORDER BY created_at DESC");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Doctors</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_doctor) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_doctor) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
            ' . (isset($edit_doctor) ? '<input type="hidden" name="id" value="' . $edit_doctor['id'] . '">' : '') . '
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="picture">
                    Picture
                </label>
                ' . (isset($edit_doctor) ? '
                <div class="mb-2">
                    <img src="uploads/' . htmlspecialchars($edit_doctor['picture']) . '" 
                         alt="Current Picture" 
                         class="h-20 w-20 rounded-full object-cover">
                </div>
                ' : '') . '
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="picture" name="picture" type="file" accept="image/*">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_doctor) ? htmlspecialchars($edit_doctor['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="details">
                    Doctor Details *
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="details" name="details" rows="3" required>' . (isset($edit_doctor) ? htmlspecialchars($edit_doctor['details']) : '') . '</textarea>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       value="' . (isset($edit_doctor) ? htmlspecialchars($edit_doctor['phone_number']) : '') . '">
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_doctor) ? 'Update Doctor' : 'Add Doctor') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Picture</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Details</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($doctors as $doctor) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <img src="uploads/' . htmlspecialchars($doctor['picture']) . '" 
                             alt="' . htmlspecialchars($doctor['name']) . '" 
                             class="h-10 w-10 rounded-full object-cover">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($doctor['name']) . '</td>
                    <td class="px-6 py-4">' . htmlspecialchars($doctor['details']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($doctor['phone_number']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $doctor['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $doctor['id'] . '" onclick="return confirm(\'Are you sure you want to delete this doctor?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 