# Backend Dashboard

A modern, responsive dashboard built with PHP, MySQL, and Tailwind CSS for managing emergency numbers, hospitals, doctors, schools, and banks.

## Features

- Emergency Numbers Management
- Hospital Information Management
- Doctor Profiles Management
- School Information Management
- Bank Information Management
- Responsive Design
- Modern UI with Tailwind CSS
- Form Validation
- Image Upload Support

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- XAMPP/WAMP/LAMP stack

## Installation

1. Clone the repository to your web server directory:
```bash
git clone [repository-url]
```

2. Import the database schema:
   - Open phpMyAdmin
   - Create a new database named `backend_dashboard`
   - Import the `database/schema.sql` file

3. Configure the database connection:
   - Open `config/database.php`
   - Update the database credentials if needed:
     ```php
     $host = 'localhost';
     $dbname = 'backend_dashboard';
     $username = 'root';
     $password = '';
     ```

4. Create an uploads directory:
```bash
mkdir uploads
chmod 777 uploads
```

5. Access the dashboard through your web browser:
```
http://localhost/backend-dashboard
```

## Usage

1. Emergency Numbers
   - Add, view, edit, and delete emergency contact numbers
   - Required fields: Name, Phone Number
   - Optional field: Description

2. Hospitals
   - Add, view, edit, and delete hospital information
   - Required fields: Name, Phone Number, Google Map Location
   - Optional field: Description

3. Doctors
   - Add, view, edit, and delete doctor profiles
   - Required fields: Name, Doctor Details, Phone Number
   - Optional field: Picture

4. Schools
   - Add, view, edit, and delete school information
   - Required fields: Category, Type, Name, Google Map Location
   - Optional field: Description

5. Banks
   - Add, view, edit, and delete bank information
   - Required fields: Name, Type, Google Map Location
   - Optional field: Description

## Security Notes

- Always keep your database credentials secure
- Ensure proper file permissions on the uploads directory
- Validate all user inputs
- Use HTTPS in production

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

This project is licensed under the MIT License. 