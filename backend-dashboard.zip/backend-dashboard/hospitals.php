<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM hospitals WHERE id = ?");
        $stmt->execute([$id]);
        $message = 'Hospital deleted successfully';
        header("Location: hospitals.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting hospital: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM hospitals WHERE id = ?");
        $stmt->execute([$id]);
        $edit_hospital = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching hospital: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $google_map_location = sanitizeInput($_POST['google_map_location']);
    $description = sanitizeInput($_POST['description']);

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!preg_match('/^[0-9]+$/', $phone_number)) {
        $error = 'Phone number must contain only numbers';
    } elseif (strlen($phone_number) < 1 || strlen($phone_number) > 20) {
        $error = 'Phone number must be between 1 to 20 characters';
    } elseif (!validateGoogleMapUrl($google_map_location)) {
        $error = 'Invalid Google Maps URL';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM hospitals WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                // Check for duplicate name
                $check_stmt = $pdo->prepare("SELECT id FROM hospitals WHERE name = ? AND id != ?");
                $check_stmt->execute([$name, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
                $existing = $check_stmt->fetch();

                if ($existing) {
                    $error = 'A hospital with this name already exists';
                } else {
                    if (isset($_POST['id'])) {
                        // Update existing record
                        $id = (int)$_POST['id'];
                        $stmt = $pdo->prepare("UPDATE hospitals SET name = ?, phone_number = ?, google_map_location = ?, description = ? WHERE id = ?");
                        $stmt->execute([$name, $phone_number, $google_map_location, $description, $id]);
                        $message = 'Hospital updated successfully';
                    } else {
                        // Insert new record
                        $stmt = $pdo->prepare("INSERT INTO hospitals (name, phone_number, google_map_location, description) VALUES (?, ?, ?, ?)");
                        $stmt->execute([$name, $phone_number, $google_map_location, $description]);
                        $message = 'Hospital added successfully';
                    }
                    header("Location: hospitals.php?message=" . urlencode($message));
                    exit();
                }
            }
        } catch (PDOException $e) {
            $error = 'Error saving hospital: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all hospitals
$stmt = $pdo->query("SELECT * FROM hospitals ORDER BY created_at DESC");
$hospitals = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Hospitals</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_hospital) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_hospital) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" class="space-y-4" onsubmit="return true;">
            ' . (isset($edit_hospital) ? '<input type="hidden" name="id" value="' . $edit_hospital['id'] . '">' : '') . '
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_hospital) ? htmlspecialchars($edit_hospital['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       pattern="[0-9]*" 
                       inputmode="numeric"
                       onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                       value="' . (isset($edit_hospital) ? htmlspecialchars($edit_hospital['phone_number']) : '') . '">
                <p class="text-gray-500 text-xs mt-1">Only numbers are allowed</p>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="google_map_location">
                    Google Map Location *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="google_map_location" name="google_map_location" type="url" required
                       placeholder="https://maps.app.goo.gl/..."
                       value="' . (isset($edit_hospital) ? htmlspecialchars($edit_hospital['google_map_location']) : '') . '">
                <p class="text-gray-500 text-xs mt-1">URL must start with https://maps.app.goo.gl/</p>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_hospital) ? htmlspecialchars($edit_hospital['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_hospital) ? 'Update Hospital' : 'Add Hospital') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Map Location</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">';

foreach ($hospitals as $hospital) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($hospital['name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($hospital['phone_number']) . '</td>
                    <td class="px-6 py-4">
                        <a href="' . htmlspecialchars($hospital['google_map_location']) . '" target="_blank" class="text-blue-600 hover:text-blue-900">
                            View Location
                        </a>
                    </td>
                    <td class="px-6 py-4">' . htmlspecialchars($hospital['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $hospital['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $hospital['id'] . '" onclick="return confirm(\'Are you sure you want to delete this hospital?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 