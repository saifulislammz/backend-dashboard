<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category = sanitizeInput($_POST['category']);
    $type = sanitizeInput($_POST['type']);
    $name = sanitizeInput($_POST['name']);
    $google_map_location = sanitizeInput($_POST['google_map_location']);
    $description = sanitizeInput($_POST['description']);

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!validateGoogleMapUrl($google_map_location)) {
        $error = 'Invalid Google Maps URL';
    } else {
        try {
            if (isset($_POST['id'])) {
                // Update existing record
                $id = (int)$_POST['id'];
                $stmt = $pdo->prepare("UPDATE schools SET category = ?, type = ?, name = ?, google_map_location = ?, description = ? WHERE id = ?");
                $stmt->execute([$category, $type, $name, $google_map_location, $description, $id]);
                $message = 'School updated successfully';
            } else {
                // Insert new record
                $stmt = $pdo->prepare("INSERT INTO schools (category, type, name, google_map_location, description) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$category, $type, $name, $google_map_location, $description]);
                $message = 'School added successfully';
            }
            header("Location: schools.php?message=" . urlencode($message));
            exit();
        } catch (PDOException $e) {
            $error = 'Error saving school: ' . $e->getMessage();
        }
    }
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        $stmt = $pdo->prepare("DELETE FROM schools WHERE id = ?");
        $stmt->execute([$id]);
        $message = 'School deleted successfully';
        header("Location: schools.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting school: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM schools WHERE id = ?");
        $stmt->execute([$id]);
        $edit_school = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching school: ' . $e->getMessage();
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all schools
$stmt = $pdo->query("SELECT * FROM schools ORDER BY created_at DESC");
$schools = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Schools</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_school) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_school) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" class="space-y-4">
            ' . (isset($edit_school) ? '<input type="hidden" name="id" value="' . $edit_school['id'] . '">' : '') . '
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="category">
                    Category *
                </label>
                <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                        id="category" name="category" required>
                    <option value="">Select Category</option>
                    <option value="Madrasha" ' . (isset($edit_school) && $edit_school['category'] === 'Madrasha' ? 'selected' : '') . '>Madrasha</option>
                    <option value="School" ' . (isset($edit_school) && $edit_school['category'] === 'School' ? 'selected' : '') . '>School</option>
                    <option value="College" ' . (isset($edit_school) && $edit_school['category'] === 'College' ? 'selected' : '') . '>College</option>
                </select>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="type">
                    Type *
                </label>
                <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                        id="type" name="type" required>
                    <option value="">Select Type</option>
                    <option value="Government" ' . (isset($edit_school) && $edit_school['type'] === 'Government' ? 'selected' : '') . '>Government</option>
                    <option value="Semi-Government" ' . (isset($edit_school) && $edit_school['type'] === 'Semi-Government' ? 'selected' : '') . '>Semi-Government</option>
                    <option value="Private" ' . (isset($edit_school) && $edit_school['type'] === 'Private' ? 'selected' : '') . '>Private</option>
                </select>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_school) ? htmlspecialchars($edit_school['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="google_map_location">
                    Google Map Location *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="google_map_location" name="google_map_location" type="url" required
                       value="' . (isset($edit_school) ? htmlspecialchars($edit_school['google_map_location']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_school) ? htmlspecialchars($edit_school['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_school) ? 'Update School' : 'Add School') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Map Location</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($schools as $school) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($school['category']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($school['type']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($school['name']) . '</td>
                    <td class="px-6 py-4">
                        <a href="' . htmlspecialchars($school['google_map_location']) . '" target="_blank" class="text-blue-600 hover:text-blue-900">
                            View Location
                        </a>
                    </td>
                    <td class="px-6 py-4">' . htmlspecialchars($school['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $school['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $school['id'] . '" onclick="return confirm(\'Are you sure you want to delete this school?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 