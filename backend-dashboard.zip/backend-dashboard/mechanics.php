<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        // First get the picture filename to delete it from uploads
        $stmt = $pdo->prepare("SELECT picture FROM mechanics WHERE id = ?");
        $stmt->execute([$id]);
        $mechanic = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delete the record
        $stmt = $pdo->prepare("DELETE FROM mechanics WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete the picture file if it's not the default
        if ($mechanic && $mechanic['picture'] !== 'default-person.png') {
            $picture_path = 'uploads/' . $mechanic['picture'];
            if (file_exists($picture_path)) {
                unlink($picture_path);
            }
        }
        
        $message = 'Mechanic deleted successfully';
        header("Location: mechanics.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting mechanic: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM mechanics WHERE id = ?");
        $stmt->execute([$id]);
        $edit_mechanic = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching mechanic: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $description = sanitizeInput($_POST['description']);
    $picture = isset($edit_mechanic) ? $edit_mechanic['picture'] : 'default-person.png';

    if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
        $upload_result = handleFileUpload($_FILES['picture']);
        if ($upload_result) {
            // Delete old picture if it's not the default
            if (isset($edit_mechanic) && $edit_mechanic['picture'] !== 'default-person.png') {
                $old_picture_path = 'uploads/' . $edit_mechanic['picture'];
                if (file_exists($old_picture_path)) {
                    unlink($old_picture_path);
                }
            }
            $picture = basename($upload_result);
        } else {
            $error = 'Error uploading picture. Please try again.';
        }
    }

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!validateBangladeshiPhoneNumber($phone_number)) {
        $error = 'Invalid Bangladeshi phone number';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM mechanics WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                if (isset($_POST['id'])) {
                    // Update existing record
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE mechanics SET picture = ?, name = ?, phone_number = ?, description = ? WHERE id = ?");
                    $stmt->execute([$picture, $name, $phone_number, $description, $id]);
                    $message = 'Mechanic updated successfully';
                } else {
                    // Insert new record
                    $stmt = $pdo->prepare("INSERT INTO mechanics (picture, name, phone_number, description) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$picture, $name, $phone_number, $description]);
                    $message = 'Mechanic added successfully';
                }
                header("Location: mechanics.php?message=" . urlencode($message));
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Error saving mechanic: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all mechanics
$stmt = $pdo->query("SELECT * FROM mechanics ORDER BY created_at DESC");
$mechanics = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Mechanics</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_mechanic) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_mechanic) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
            ' . (isset($edit_mechanic) ? '<input type="hidden" name="id" value="' . $edit_mechanic['id'] . '">' : '') . '
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="picture">
                    Picture
                </label>
                ' . (isset($edit_mechanic) ? '
                <div class="mb-2">
                    <img src="uploads/' . htmlspecialchars($edit_mechanic['picture']) . '" 
                         alt="Current Picture" 
                         class="h-20 w-20 rounded-full object-cover">
                </div>
                ' : '') . '
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="picture" name="picture" type="file" accept="image/*">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_mechanic) ? htmlspecialchars($edit_mechanic['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       value="' . (isset($edit_mechanic) ? htmlspecialchars($edit_mechanic['phone_number']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_mechanic) ? htmlspecialchars($edit_mechanic['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_mechanic) ? 'Update Mechanic' : 'Add Mechanic') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Picture</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($mechanics as $mechanic) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <img src="uploads/' . htmlspecialchars($mechanic['picture']) . '" 
                             alt="' . htmlspecialchars($mechanic['name']) . '" 
                             class="h-10 w-10 rounded-full object-cover">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($mechanic['name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($mechanic['phone_number']) . '</td>
                    <td class="px-6 py-4">' . htmlspecialchars($mechanic['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $mechanic['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $mechanic['id'] . '" onclick="return confirm(\'Are you sure you want to delete this mechanic?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 