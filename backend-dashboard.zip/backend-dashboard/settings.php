<?php
require_once 'config/database.php';
require_once 'utils/functions.php';
require_once 'config/auth.php';

// Check authentication
checkAuth();

$message = '';
$error = '';

// Handle device removal
if (isset($_GET['remove_device'])) {
    $device_id = (int)$_GET['remove_device'];
    try {
        // Get the device info before removing it
        $stmt = $pdo->prepare("SELECT device_info FROM login_devices WHERE id = ? AND admin_id = ?");
        $stmt->execute([$device_id, $_SESSION['admin_id']]);
        $device = $stmt->fetch();
        
        if ($device) {
            // Check if the removed device is the current device
            $current_device_info = $_SERVER['HTTP_USER_AGENT'] . ' - ' . $_SERVER['REMOTE_ADDR'];
            if ($device['device_info'] === $current_device_info) {
                // If removing current device, redirect to logout
                header('Location: logout.php?redirect=settings.php');
                exit();
            } else {
                // Remove the device
                $stmt = $pdo->prepare("DELETE FROM login_devices WHERE id = ? AND admin_id = ?");
                $stmt->execute([$device_id, $_SESSION['admin_id']]);
                $message = 'Device removed successfully!';
            }
        }
    } catch (PDOException $e) {
        $error = 'Error removing device: ' . $e->getMessage();
    }
}

// Handle password change
if (isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = 'All password fields are required';
    } elseif ($new_password !== $confirm_password) {
        $error = 'New passwords do not match';
    } else {
        try {
            // Get current user's password
            $stmt = $pdo->prepare("SELECT password FROM admin_users WHERE id = ?");
            $stmt->execute([$_SESSION['admin_id']]);
            $user = $stmt->fetch();
            
            if ($user && md5($current_password) === $user['password']) {
                // Update password
                $stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = ?");
                $stmt->execute([md5($new_password), $_SESSION['admin_id']]);
                $message = 'Password changed successfully!';
            } else {
                $error = 'Current password is incorrect';
            }
        } catch (PDOException $e) {
            $error = 'Error changing password: ' . $e->getMessage();
        }
    }
}

// Get logged in devices
try {
    $stmt = $pdo->prepare("SELECT * FROM login_devices WHERE admin_id = ? ORDER BY last_login DESC");
    $stmt->execute([$_SESSION['admin_id']]);
    $devices = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = 'Error fetching devices: ' . $e->getMessage();
    $devices = [];
}

$page_title = 'Settings';

// Start output buffering
ob_start();
?>

<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white shadow-md rounded-lg overflow-hidden">
            <div class="p-6">
                <h1 class="text-2xl font-bold mb-6 text-gray-800">Settings</h1>
                
                <?php if ($message): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <span class="block sm:inline"><?php echo $message; ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <span class="block sm:inline"><?php echo $error; ?></span>
                    </div>
                <?php endif; ?>

                <!-- Logged In Devices Section -->
                <div class="mb-8">
                    <h2 class="text-xl font-semibold mb-4 text-gray-700">Logged In Devices</h2>
                    <p class="text-sm text-gray-500 mb-4">Maximum 2 devices can be logged in simultaneously. The oldest device will be automatically logged out when a new device logs in.</p>
                    <?php if (empty($devices)): ?>
                        <p class="text-gray-500">No devices currently logged in.</p>
                    <?php else: ?>
                        <div class="space-y-4">
                            <?php foreach ($devices as $device): 
                                // Parse device info
                                $device_parts = explode(' - ', $device['device_info']);
                                $user_agent = $device_parts[0];
                                $ip_address = $device_parts[1] ?? 'Unknown IP';
                                
                                // Parse browser info
                                if (preg_match('/Chrome\/([0-9.]+)/', $user_agent, $matches)) {
                                    $browser = 'Chrome ' . $matches[1];
                                } elseif (preg_match('/Firefox\/([0-9.]+)/', $user_agent, $matches)) {
                                    $browser = 'Firefox ' . $matches[1];
                                } elseif (preg_match('/Safari\/([0-9.]+)/', $user_agent, $matches)) {
                                    $browser = 'Safari ' . $matches[1];
                                } else {
                                    $browser = 'Unknown Browser';
                                }
                                
                                // Parse OS info
                                if (preg_match('/Windows NT ([0-9.]+)/', $user_agent, $matches)) {
                                    $os = 'Windows ' . $matches[1];
                                } elseif (preg_match('/Mac OS X ([0-9._]+)/', $user_agent, $matches)) {
                                    $os = 'Mac OS X ' . str_replace('_', '.', $matches[1]);
                                } elseif (preg_match('/Linux/', $user_agent)) {
                                    $os = 'Linux';
                                } else {
                                    $os = 'Unknown OS';
                                }
                            ?>
                                <div class="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                                    <div class="flex items-center space-x-4">
                                        <div class="bg-blue-100 p-3 rounded-full">
                                            <i class="fas fa-laptop text-blue-600"></i>
                                        </div>
                                        <div>
                                            <div class="flex items-center space-x-2">
                                                <p class="text-gray-800 font-medium"><?php echo htmlspecialchars($browser); ?></p>
                                                <span class="text-gray-400">•</span>
                                                <p class="text-gray-600 text-sm"><?php echo htmlspecialchars($os); ?></p>
                                            </div>
                                            <div class="flex items-center space-x-2 mt-1">
                                                <p class="text-gray-500 text-sm">
                                                    <i class="fas fa-globe mr-1"></i>
                                                    <?php echo htmlspecialchars($ip_address); ?>
                                                </p>
                                                <span class="text-gray-400">•</span>
                                                <p class="text-gray-500 text-sm">
                                                    <i class="fas fa-clock mr-1"></i>
                                                    Last login: <?php echo date('M d, Y H:i', strtotime($device['last_login'])); ?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="?remove_device=<?php echo $device['id']; ?>" 
                                       class="text-red-600 hover:text-red-800 p-2 rounded-full hover:bg-red-100 transition-colors duration-200"
                                       onclick="return confirm('Are you sure you want to remove this device?')">
                                        <i class="fas fa-times-circle"></i>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Change Password Section -->
                <div>
                    <h2 class="text-xl font-semibold mb-4 text-gray-700">Change Password</h2>
                    <form method="POST" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="current_password" class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                                <input type="password" name="current_password" id="current_password" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="new_password" class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                                <input type="password" name="new_password" id="new_password" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="confirm_password" class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                                <input type="password" name="confirm_password" id="confirm_password" required
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                            </div>
                            <div class="flex items-end">
                                <button type="submit" name="change_password" 
                                        class="w-full md:w-auto px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                    Change Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Get the buffered content
$content = ob_get_clean();

// Include the main layout
require_once 'layouts/main.php';
?> 