<?php
require_once 'config/database.php';
require_once 'utils/functions.php';
require_once 'config/auth.php';

// Check authentication
checkAuth();

// Get search parameters
$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$category = isset($_GET['category']) ? $_GET['category'] : 'all';

$page_title = 'Search Results';

// Start output buffering
ob_start();
?>

<div class="container mx-auto px-4 py-8">
    <!-- Search Form -->
    <div class="mb-8">
        <form action="search.php" method="GET" class="flex items-center max-w-3xl mx-auto">
            <div class="relative flex-1">
                <input type="text" 
                       name="q" 
                       value="<?php echo htmlspecialchars($query); ?>"
                       class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       placeholder="Search anything..."
                       autocomplete="off">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i class="fas fa-search text-gray-400"></i>
                </div>
            </div>
            <div class="ml-2">
                <select name="category" 
                        class="border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="all" <?php echo $category === 'all' ? 'selected' : ''; ?>>All Categories</option>
                    <option value="emergency_numbers" <?php echo $category === 'emergency_numbers' ? 'selected' : ''; ?>>Emergency Numbers</option>
                    <option value="hospitals" <?php echo $category === 'hospitals' ? 'selected' : ''; ?>>Hospitals</option>
                    <option value="doctors" <?php echo $category === 'doctors' ? 'selected' : ''; ?>>Doctors</option>
                    <option value="schools" <?php echo $category === 'schools' ? 'selected' : ''; ?>>Schools</option>
                    <option value="banks" <?php echo $category === 'banks' ? 'selected' : ''; ?>>Banks</option>
                </select>
            </div>
            <button type="submit" 
                    class="ml-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                Search
            </button>
        </form>
    </div>

    <!-- Search Results -->
    <div class="space-y-6">
        <?php
        // Function to get all items from a table
        function getAllItems($pdo, $table) {
            $sql = "SELECT * FROM $table ORDER BY name ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Function to search in a table
        function searchTable($pdo, $table, $query, $fields) {
            $conditions = [];
            $params = [];
            
            foreach ($fields as $field) {
                $conditions[] = "$field LIKE ?";
                $params[] = "%$query%";
            }
            
            $sql = "SELECT * FROM $table WHERE " . implode(" OR ", $conditions) . " ORDER BY name ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Define search fields for each table based on actual schema
        $tableFields = [
            'emergency_numbers' => ['name', 'phone_number', 'description'],
            'hospitals' => ['name', 'phone_number', 'google_map_location', 'description'],
            'doctors' => ['name', 'details', 'phone_number'],
            'schools' => ['name', 'category', 'type', 'google_map_location', 'description'],
            'banks' => ['name', 'type', 'google_map_location', 'description']
        ];

        if (empty($query)) {
            // Show all items when no search query
            if ($category === 'all') {
                // Show all categories
                foreach ($tableFields as $table => $fields) {
                    $results = getAllItems($pdo, $table);
                    if (!empty($results)) {
                        $tableName = ucwords(str_replace('_', ' ', $table));
                        echo "<div class='bg-white rounded-lg shadow-md p-6'>
                                <h2 class='text-xl font-semibold text-gray-800 mb-4'>$tableName</h2>
                                <div class='overflow-x-auto'>
                                    <table class='min-w-full divide-y divide-gray-200'>
                                        <thead class='bg-gray-50'>
                                            <tr>";
                        
                        // Display table headers based on the first result
                        foreach (array_keys($results[0]) as $field) {
                            if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                                echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>" . 
                                     ucwords(str_replace('_', ' ', $field)) . "</th>";
                            }
                        }
                        echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>Actions</th>";
                        
                        echo "</tr></thead><tbody class='bg-white divide-y divide-gray-200'>";
                        
                        // Display results
                        foreach ($results as $row) {
                            echo "<tr>";
                            foreach ($row as $field => $value) {
                                if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                                    echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . 
                                         htmlspecialchars($value) . "</td>";
                                }
                            }
                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                                    <a href='$table.php?id=" . $row['id'] . "' class='text-blue-600 hover:text-blue-900'>
                                        View Details
                                    </a>
                                  </td>";
                            echo "</tr>";
                        }
                        
                        echo "</tbody></table></div></div>";
                    }
                }
            } else {
                // Show specific category
                if (isset($tableFields[$category])) {
                    $results = getAllItems($pdo, $category);
                    if (!empty($results)) {
                        $tableName = ucwords(str_replace('_', ' ', $category));
                        echo "<div class='bg-white rounded-lg shadow-md p-6'>
                                <h2 class='text-xl font-semibold text-gray-800 mb-4'>$tableName</h2>
                                <div class='overflow-x-auto'>
                                    <table class='min-w-full divide-y divide-gray-200'>
                                        <thead class='bg-gray-50'>
                                            <tr>";
                        
                        // Display table headers based on the first result
                        foreach (array_keys($results[0]) as $field) {
                            if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                                echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>" . 
                                     ucwords(str_replace('_', ' ', $field)) . "</th>";
                            }
                        }
                        echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>Actions</th>";
                        
                        echo "</tr></thead><tbody class='bg-white divide-y divide-gray-200'>";
                        
                        // Display results
                        foreach ($results as $row) {
                            echo "<tr>";
                            foreach ($row as $field => $value) {
                                if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                                    echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . 
                                         htmlspecialchars($value) . "</td>";
                                }
                            }
                            echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                                    <a href='$category.php?id=" . $row['id'] . "' class='text-blue-600 hover:text-blue-900'>
                                        View Details
                                    </a>
                                  </td>";
                            echo "</tr>";
                        }
                        
                        echo "</tbody></table></div></div>";
                    }
                }
            }
        } else {
            // Perform search when query is provided
            $searchResults = [];
            
            if ($category === 'all') {
                foreach ($tableFields as $table => $fields) {
                    $results = searchTable($pdo, $table, $query, $fields);
                    if (!empty($results)) {
                        $searchResults[$table] = $results;
                    }
                }
            } else {
                if (isset($tableFields[$category])) {
                    $results = searchTable($pdo, $category, $query, $tableFields[$category]);
                    if (!empty($results)) {
                        $searchResults[$category] = $results;
                    }
                }
            }

            // Display search results
            if (empty($searchResults)) {
                echo '<div class="text-center py-8">
                        <i class="fas fa-search text-gray-400 text-5xl mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-700">No results found</h3>
                        <p class="text-gray-500">Try different keywords or categories</p>
                      </div>';
            } else {
                foreach ($searchResults as $table => $results) {
                    $tableName = ucwords(str_replace('_', ' ', $table));
                    echo "<div class='bg-white rounded-lg shadow-md p-6'>
                            <h2 class='text-xl font-semibold text-gray-800 mb-4'>$tableName</h2>
                            <div class='overflow-x-auto'>
                                <table class='min-w-full divide-y divide-gray-200'>
                                    <thead class='bg-gray-50'>
                                        <tr>";
                    
                    // Display table headers based on the first result
                    foreach (array_keys($results[0]) as $field) {
                        if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                            echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>" . 
                                 ucwords(str_replace('_', ' ', $field)) . "</th>";
                        }
                    }
                    echo "<th class='px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider'>Actions</th>";
                    
                    echo "</tr></thead><tbody class='bg-white divide-y divide-gray-200'>";
                    
                    // Display results
                    foreach ($results as $row) {
                        echo "<tr>";
                        foreach ($row as $field => $value) {
                            if ($field !== 'id' && $field !== 'created_at' && $field !== 'updated_at') {
                                echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>" . 
                                     htmlspecialchars($value) . "</td>";
                            }
                        }
                        echo "<td class='px-6 py-4 whitespace-nowrap text-sm text-gray-500'>
                                <a href='$table.php?id=" . $row['id'] . "' class='text-blue-600 hover:text-blue-900'>
                                    View Details
                                </a>
                              </td>";
                        echo "</tr>";
                    }
                    
                    echo "</tbody></table></div></div>";
                }
            }
        }
        ?>
    </div>
</div>

<?php
// Get the buffered content
$content = ob_get_clean();

// Include the main layout
require_once 'layouts/main.php';
?> 