<?php
require_once 'config/auth.php';
require_once 'config/database.php';

// Remove device record if user is logged in
if (isset($_SESSION['admin_id'])) {
    try {
        $device_info = $_SERVER['HTTP_USER_AGENT'] . ' - ' . $_SERVER['REMOTE_ADDR'];
        $stmt = $pdo->prepare("DELETE FROM login_devices WHERE admin_id = ? AND device_info = ?");
        $stmt->execute([$_SESSION['admin_id'], $device_info]);
    } catch (PDOException $e) {
        error_log("Error removing device record: " . $e->getMessage());
    }
}

// Store redirect URL if provided
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'login.php';

// Perform logout
logout();

// Redirect to the specified page
header('Location: ' . $redirect);
exit();
?> 