<?php
require_once 'config/database.php';
require_once 'utils/functions.php';

$message = '';
$error = '';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    try {
        // First get the picture filename to delete it from uploads
        $stmt = $pdo->prepare("SELECT picture FROM blood_donors WHERE id = ?");
        $stmt->execute([$id]);
        $donor = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Delete the record
        $stmt = $pdo->prepare("DELETE FROM blood_donors WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete the picture file if it's not the default
        if ($donor && $donor['picture'] !== 'default-person.png') {
            $picture_path = 'uploads/' . $donor['picture'];
            if (file_exists($picture_path)) {
                unlink($picture_path);
            }
        }
        
        $message = 'Blood donor deleted successfully';
        header("Location: blood_donors.php?message=" . urlencode($message));
        exit();
    } catch (PDOException $e) {
        $error = 'Error deleting blood donor: ' . $e->getMessage();
    }
}

// Handle Edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    try {
        $stmt = $pdo->prepare("SELECT * FROM blood_donors WHERE id = ?");
        $stmt->execute([$id]);
        $edit_donor = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        $error = 'Error fetching blood donor: ' . $e->getMessage();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitizeInput($_POST['name']);
    $phone_number = sanitizeInput($_POST['phone_number']);
    $blood_type = sanitizeInput($_POST['blood_type']);
    $description = sanitizeInput($_POST['description']);
    $picture = isset($edit_donor) ? $edit_donor['picture'] : 'default-person.png';

    if (isset($_FILES['picture']) && $_FILES['picture']['error'] === UPLOAD_ERR_OK) {
        $upload_result = handleFileUpload($_FILES['picture']);
        if ($upload_result) {
            // Delete old picture if it's not the default
            if (isset($edit_donor) && $edit_donor['picture'] !== 'default-person.png') {
                $old_picture_path = 'uploads/' . $edit_donor['picture'];
                if (file_exists($old_picture_path)) {
                    unlink($old_picture_path);
                }
            }
            $picture = basename($upload_result);
        } else {
            $error = 'Error uploading picture. Please try again.';
        }
    }

    if (empty($name)) {
        $error = 'Name is required';
    } elseif (!validateBangladeshiPhoneNumber($phone_number)) {
        $error = 'Invalid Bangladeshi phone number';
    } elseif (empty($blood_type)) {
        $error = 'Blood type is required';
    } else {
        try {
            // Check for duplicate phone number
            $check_stmt = $pdo->prepare("SELECT id FROM blood_donors WHERE phone_number = ? AND id != ?");
            $check_stmt->execute([$phone_number, isset($_POST['id']) ? (int)$_POST['id'] : 0]);
            $existing = $check_stmt->fetch();

            if ($existing) {
                $error = 'This phone number already exists in the system';
            } else {
                if (isset($_POST['id'])) {
                    // Update existing record
                    $id = (int)$_POST['id'];
                    $stmt = $pdo->prepare("UPDATE blood_donors SET picture = ?, name = ?, phone_number = ?, blood_type = ?, description = ? WHERE id = ?");
                    $stmt->execute([$picture, $name, $phone_number, $blood_type, $description, $id]);
                    $message = 'Blood donor updated successfully';
                } else {
                    // Insert new record
                    $stmt = $pdo->prepare("INSERT INTO blood_donors (picture, name, phone_number, blood_type, description) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$picture, $name, $phone_number, $blood_type, $description]);
                    $message = 'Blood donor added successfully';
                }
                header("Location: blood_donors.php?message=" . urlencode($message));
                exit();
            }
        } catch (PDOException $e) {
            $error = 'Error saving blood donor: ' . $e->getMessage();
        }
    }
}

// Get message from URL if redirected
if (isset($_GET['message'])) {
    $message = urldecode($_GET['message']);
}

// Fetch all blood donors
$stmt = $pdo->query("SELECT * FROM blood_donors ORDER BY created_at DESC");
$donors = $stmt->fetchAll(PDO::FETCH_ASSOC);

$content = '
<div class="container mx-auto px-4">
    <div class="flex justify-between items-center mb-6">
        <h2 class="text-2xl font-bold">Blood Donors</h2>
        <button onclick="document.getElementById(\'addForm\').classList.toggle(\'hidden\')" 
                class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            ' . (isset($edit_donor) ? 'Cancel Edit' : 'Add New') . '
        </button>
    </div>

    ' . ($error ? showAlert($error, 'error') : '') . '
    ' . ($message ? showAlert($message, 'success') : '') . '

    <div id="addForm" class="' . (isset($edit_donor) ? '' : 'hidden') . ' bg-white p-6 rounded-lg shadow-md mb-6">
        <form method="POST" enctype="multipart/form-data" class="space-y-4">
            ' . (isset($edit_donor) ? '<input type="hidden" name="id" value="' . $edit_donor['id'] . '">' : '') . '
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="picture">
                    Picture
                </label>
                ' . (isset($edit_donor) ? '
                <div class="mb-2">
                    <img src="uploads/' . htmlspecialchars($edit_donor['picture']) . '" 
                         alt="Current Picture" 
                         class="h-20 w-20 rounded-full object-cover">
                </div>
                ' : '') . '
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="picture" name="picture" type="file" accept="image/*">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="name">
                    Name *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="name" name="name" type="text" required
                       value="' . (isset($edit_donor) ? htmlspecialchars($edit_donor['name']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="phone_number">
                    Phone Number *
                </label>
                <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                       id="phone_number" name="phone_number" type="text" required
                       value="' . (isset($edit_donor) ? htmlspecialchars($edit_donor['phone_number']) : '') . '">
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="blood_type">
                    Blood Type *
                </label>
                <select class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                        id="blood_type" name="blood_type" required>
                    <option value="">Select Blood Type</option>
                    <option value="O+" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'O+' ? 'selected' : '') . '>O+</option>
                    <option value="O-" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'O-' ? 'selected' : '') . '>O-</option>
                    <option value="A+" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'A+' ? 'selected' : '') . '>A+</option>
                    <option value="A-" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'A-' ? 'selected' : '') . '>A-</option>
                    <option value="B+" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'B+' ? 'selected' : '') . '>B+</option>
                    <option value="B-" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'B-' ? 'selected' : '') . '>B-</option>
                    <option value="AB+" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'AB+' ? 'selected' : '') . '>AB+</option>
                    <option value="AB-" ' . (isset($edit_donor) && $edit_donor['blood_type'] === 'AB-' ? 'selected' : '') . '>AB-</option>
                </select>
            </div>
            
            <div>
                <label class="block text-gray-700 text-sm font-bold mb-2" for="description">
                    Description
                </label>
                <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" 
                          id="description" name="description" rows="3">' . (isset($edit_donor) ? htmlspecialchars($edit_donor['description']) : '') . '</textarea>
            </div>
            
            <div class="flex items-center justify-end">
                <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" 
                        type="submit">
                    ' . (isset($edit_donor) ? 'Update Blood Donor' : 'Add Blood Donor') . '
                </button>
            </div>
        </form>
    </div>

    <div class="bg-white shadow-md rounded-lg overflow-hidden">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Picture</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone Number</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Blood Type</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
';

foreach ($donors as $donor) {
    $content .= '
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <img src="uploads/' . htmlspecialchars($donor['picture']) . '" 
                             alt="' . htmlspecialchars($donor['name']) . '" 
                             class="h-10 w-10 rounded-full object-cover">
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($donor['name']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($donor['phone_number']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap">' . htmlspecialchars($donor['blood_type']) . '</td>
                    <td class="px-6 py-4">' . htmlspecialchars($donor['description']) . '</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <a href="?edit=' . $donor['id'] . '" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                        <a href="?delete=' . $donor['id'] . '" onclick="return confirm(\'Are you sure you want to delete this blood donor?\')" 
                           class="text-red-600 hover:text-red-900">Delete</a>
                    </td>
                </tr>
    ';
}

$content .= '
            </tbody>
        </table>
    </div>
</div>
';

require_once 'layouts/main.php';
?> 